# ODESCA 1.0
ODESCA is a MATLAB tool for the creation and analysis of dynamic systems 
described by ordinary differential equations.

Learn more about ODESCA in <https://github.com/odesca/ODESCA/wiki>
